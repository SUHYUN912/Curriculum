package com.example.mymemo;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Fragment1 #newInstance} factory method to
 * create an instance of this fragment.
 */
public class Fragment1 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_1, container, false);

        DatePicker dp = view.findViewById(R.id.datePicker);
        int year = dp.getYear();
        int month = dp.getMonth();
        int day = dp.getDayOfMonth();

        dp.init(year, month, day, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int month, int day) {
                String today = year + " " + (month+1) +" "+ day;
                Log.d("Today", today);
            }
        });

        return view;
    }
}