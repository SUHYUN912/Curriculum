package com.example.clickeventtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);

        findViewById(R.id.btn1).setOnClickListener(this);
        findViewById(R.id.btn2).setOnClickListener(this);
        findViewById(R.id.btn3).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btn1:
                Toast.makeText(this, "BTN1 !!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn2:
                Toast.makeText(this, "BTN2 !!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn3:
                String str_name = name.getText().toString();
                if(str_name.length()<5)
                    Toast.makeText(this, "이름을 다시 입력하세요", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(this, str_name + "환영해요!", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}