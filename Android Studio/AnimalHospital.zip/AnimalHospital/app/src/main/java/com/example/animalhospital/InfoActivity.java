package com.example.animalhospital;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class InfoActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        findViewById(R.id.btn_info_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(InfoActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}