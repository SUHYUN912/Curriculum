package com.example.animalhospital;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class InfoActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        Intent intent = getIntent();
        String str = intent.getStringExtra("info");
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();

        findViewById(R.id.btn_info_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View view){
        finish();
    }
}