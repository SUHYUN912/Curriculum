package com.example.animalhospital;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText userid;
    EditText passwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userid = findViewById(R.id.userid);
        passwd = findViewById(R.id.passwd);


        findViewById(R.id.btn_info).setOnClickListener(this);
        findViewById(R.id.btn_guide).setOnClickListener(this);
        findViewById(R.id.btn_login).setOnClickListener(this);
        findViewById(R.id.btn_call).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_info:
                //Toast.makeText(this, "병원소개 버튼을 클릭하였습니다", Toast.LENGTH_SHORT).show();
                Intent info_intent = new Intent(MainActivity.this, InfoActivity.class);
                startActivity(info_intent);
                Toast.makeText(this, "안전한 진료를 위한 시스템 구축", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn_guide:
                //Toast.makeText(this, "진료안내 버튼을 클릭하였습니다", Toast.LENGTH_SHORT).show();
                Intent guide_intent = new Intent(MainActivity.this, GuideActivity.class);
                startActivity(guide_intent);
                Toast.makeText(this, "진료시간을 확인하세요!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn_call:
                Intent call_intent = new Intent(MainActivity.this, CallActivity.class);
                startActivity(call_intent);
                Toast.makeText(this, "상담신청하세요!", Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn_login:
                String str_id = userid.getText().toString();
                String str_pw = passwd.getText().toString();
                if (str_id.length() < 5) {
                    Toast.makeText(this, "아이디를 다시 입력하세요", Toast.LENGTH_SHORT).show();
                } else if (str_pw.length() < 8) {
                    Toast.makeText(this, "패스워드를 다시 입력하세요", Toast.LENGTH_SHORT).show();
                } else if (str_id.equals("SeoulRobot") && str_pw.equals("12345678")) {
                    Toast.makeText(this, str_id + "님의 방문을 환영합니다.", Toast.LENGTH_SHORT).show();
                } else if (str_id != "SeoulRobot" || str_pw != "12345678") {
                    Toast.makeText(this, "아이디와 패스워드가 일치하지 않습니다", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}